#ifndef Domain_H
#define Domain_H

class Domain
{
private:

public:

};

#endif
